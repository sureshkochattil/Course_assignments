# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 17:54:46 2020

@author: AdamSullivan
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv('C:/Users/AdamSullivan/Documents/School/IUPeakProjectData.txt', sep="\t")
df2 = df.copy()

###############################################################################
duke_ids = ['4440099', '4440105', '4440012', '4440073', '4440177'] # '4440104',

df_new = df2[df2.iloc[:, 0].isin(duke_ids)]

df_4440104 = df2[df2.iloc[:, 0].isin(['4440104'])]

df_4440104['READ_DT'] = pd.to_datetime(df_4440104['READ_DT'])
end_date = df_4440104['READ_DT'] < '03-28-2019'

df_4440104 = df_4440104[end_date]


df_new2 = pd.concat([df_new,df_4440104])


###############################################################################

column_names = ['METER_ID', 'CHANNEL_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_5MIN_INT', 'READ_DTM', 'READ_VALUE', 'UOM', 'STATUS', 'READ_VERSION']

meter_4440104_meters_ids = ['4440017','4440038','4440081','4440084','4440107','4440109','4440110','4440111','4440112','4440113','4440116','4440117',
                            '4440135','4440136','KZD052439471','KZD052439548','KZD052439555','KZD052439556','X8D054382940','X9D053773966','X9D053773967','X9D053806594','X9D053806620',
                            '4440018','4440030','4440015','4440036','4440005','4440011']

df_4440104_meters_ids = df[df.iloc[:, 0].isin(meter_4440104_meters_ids)]  #704232 records

df_4440104_meters_ids.loc[:,'METER_ID'] = '4440104' #704232 records
df_4440104_meters_ids.loc[:,'STATUS'] = '1' 

df = df_4440104_meters_ids.copy()

df_4440104_grouped = df.groupby(['METER_ID', 'CHANNEL_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_5MIN_INT', 'READ_DTM', 'UOM', 'STATUS', 'READ_VERSION']).sum().reset_index()

df_4440104_grouped = df_4440104_grouped.reindex(columns=column_names)

df = df_4440104_grouped.copy()

df['READ_DT'] = pd.to_datetime(df['READ_DT'])
df['READ_DTM'] = pd.to_datetime(df['READ_DTM'])

meter_estimates = [['03-28-2019', '04-29-2019', 2687530], 
                   ['04-29-2019', '05-29-2019', 2242982], 
                   ['05-29-2019', '06-27-2019', 2088403], 
                   ['06-27-2019', '07-29-2019', 2931763], 
                   ['07-29-2019', '08-27-2019', 2709715], 
                   ['08-27-2019', '09-26-2019', 2861270], 
                   ['09-26-2019', '10-25-2019', 2439763], 
                   ['10-25-2019', '11-26-2019', 3014534], 
                   ['11-26-2019', '12-28-2019', 3134141] ]


for month in meter_estimates:
    start,end,total = month

    start_date = df['READ_DT'] >= start
    end_date = df['READ_DT'] < end
    
    df_slice = df[start_date & end_date]
    
    ratio = total / df_slice['READ_VALUE'].sum()

    df_slice['READ_VALUE'] = round(df_slice['READ_VALUE'] * ratio)
        
    df_new2 = pd.concat([df_new2,df_slice])



start = '12-28-2019'
start_date = df['READ_DT'] >= start
df_slice = df[start_date]
df_slice['READ_VALUE'] = round(df_slice['READ_VALUE'] * ratio)
df_new2 = pd.concat([df_new2,df_slice])


df_new2.to_csv('C:/Users/AdamSullivan/Documents/School/IUPeakProjectDataMainMeters2.txt', sep="\t")


