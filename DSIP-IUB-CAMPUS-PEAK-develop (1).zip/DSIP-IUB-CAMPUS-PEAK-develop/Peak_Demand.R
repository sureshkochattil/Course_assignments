
setwd("D:/Peak_Demand")


# Load the subset of the dataset for only the six main meters

main_meters = read.delim("IUPeakProjectDataMainMeters.txt", header = TRUE, sep = "\t")
main_meters_df = data.frame(main_meters)
View(main_meters_df)


# Converting to date data type and extracting the date
main_meters_df["Date"] = format(as.POSIXct(main_meters_df$READ_DTM,format='%d-%b-%y %H:%M:%S'),format='%m/%d/%Y')
View(main_meters_df)


# Dropping redundant columns

main_meters_trim = select(main_meters_df, - CHANNEL_ID, -READ_DT, -READ_30MIN_INT, -READ_15MIN_INT,
                        -READ_5MIN_INT, -READ_DTM, -UOM, -STATUS, -READ_VERSION)
View(main_meters_trim)

# Filtering the rows where the individual meter readings are maximum for each day

group_max_trim <- main_meters_trim %>% 
  group_by(METER_ID, Date) %>%
  filter(READ_VALUE == max(READ_VALUE))
  #arrange(METER_ID,Date,READ_VALUE, READ_HR)

View(group_max_trim )

#View(group_daily_df)

library(dplyr)


# Loading the weather data
weather = read.delim("weather_2019_hourly.txt", header = TRUE, sep = ",")
weather_df = data.frame(weather)
View(weather_df)


# Dropping unwanted columns
weather_df_trim = within(weather_df, rm(Contributing.Stations, Resolved.Address, Location, Address))

head(weather_df_trim)

# Converting to date data type and extracting the date and hour of the day 

weather_df_trim["Date"] = format(as.POSIXct(weather_df_trim$Date.time,format='%m/%d/%Y %H:%M:%S'),format='%m/%d/%Y')

weather_df_trim["READ_HR"] = format(as.POSIXct(weather_df_trim$Date.time,format='%m/%d/%Y %H:%M:%S'),format='%H')
View(weather_df_trim)


# Converting to numeric
weather_df_trim$READ_HR <- sapply(weather_df_trim$READ_HR,as.numeric)
#data.class(weather_df_trim$READ_HR)

merged_df <- merge(group_max_trim, weather_df_trim, by= c('Date', "READ_HR"), all.x = TRUE)
View(merged_df)

### OLD MERGES

# Merging the two dataframes
#merged_df <- group_max_trim %>% right_join(weather_df_trim, by=c("Date", "READ_HR"))
#merged_df = merged_df [!duplicated(merged_df[c(1,2)]),]
#View(merged_df)

# Merging the two dataframes
#merged_df_try <- weather_df_trim %>% right_join(group_max_trim, by=c("Date", "READ_HR"))
#merged_df_try = merged_df_try [!duplicated(merged_df_try[c(2,3)]),]
#View(merged_df_try)

# Merging the two dataframes
merged_df <- group_max_trim %>% left_join(weather_df_trim, by=c("Date", "READ_HR"))
#merged_df = merged_df [!duplicated(merged_df[c(1,2,3)]),]
#merged_df_dedup = merged_df[!duplicated(merged_df$METER_ID & merged_df$READ_HR), ]
merged_df_dedup = merged_df %>% distinct(Date, READ_HR, .keep_all = TRUE)
View(merged_df_dedup)



# Dropping extra fields
merged_trim = select(merged_df_dedup, - Date.time, - Heat.Index, - Precipitation, - Snow.Depth)
View(merged_trim)


# Converting the data types
merged_trim$Conditions <- factor(merged_trim$Conditions)

View(merged_trim)


# Filtering individual meters

filter_4440099 = merged_trim[merged_trim$METER_ID == "4440099", ]
#View(filter_4440099)

filter_4440104 = merged_trim[merged_trim$METER_ID == "4440104", ]
#View(filter_4440104)

filter_4440105 = merged_trim[merged_trim$METER_ID == "4440105", ]
#View(filter_4440105)

filter_4440012 = merged_trim[merged_trim$METER_ID == "4440012", ]
#View(filter_4440012)

filter_4440073 = merged_trim[merged_trim$METER_ID == "4440073", ]
#View(filter_4440073)

filter_4440177 = merged_trim[merged_trim$METER_ID == "4440177", ]
#View(filter_4440177)

# Plotting the distribution of indivdual meters

library(ggplot2)
ggplot(filter_4440099, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID:4440099")

ggplot(filter_4440104, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID:4440104")

ggplot(filter_4440105, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID:4440105")

ggplot(filter_4440012, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID :4440012")

ggplot(filter_4440073, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID :4440073")

ggplot(filter_4440177, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Meter_ID :4440177")

# Relative humidity


ggplot(filter_4440099, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440099")

ggplot(filter_4440104, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440104")

ggplot(filter_4440105, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440105")

ggplot(filter_4440012, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440012")

ggplot(filter_4440073, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440073")

ggplot(filter_4440177, aes(x= Relative.Humidity))+
  geom_density() + ggtitle("Meter_ID : 4440177")

# Plotting against other regressors

ggplot(filter_4440099, aes(x= READ_HR))+
  geom_density()

ggplot(filter_4440099, aes(x= Wind.Chill))+
  geom_density()

ggplot(filter_4440099, aes(x= Wind.Speed))+
  geom_density()

ggplot(filter_4440099, aes(x= Cloud.Cover))+
  geom_density()

ggplot(filter_4440099, aes(x= Conditions))+
  geom_density()

ggplot(filter_4440099, aes(x= READ_VALUE))+
  geom_density()

library(tidyverse)
library(broom)
# Fitting regression models for individual meters using different combination regressors

filter_4440099.lm = lm(READ_VALUE ~  Maximum.Temperature + Relative.Humidity, data = filter_4440099)
summary(filter_4440099.lm)
filter_4440099.lm.df = augment(filter_4440099.lm)
ggplot(filter_4440099.lm.df, aes(x = Maximum.Temperature, y = .resid)) + geom_point() + geom_smooth()
ggplot(filter_4440099.lm.df, aes(x = Relative.Humidity, y = .resid)) + geom_point() + geom_smooth()


filter_4440099.lm = lm(READ_VALUE ~  Maximum.Temperature + Relative.Humidity + Minimum.Temperature, 
                       data = filter_4440099)
summary(filter_4440099.lm)
filter_4440099.lm.df = augment(filter_4440099.lm)
ggplot(filter_4440099.lm.df, aes(x = Maximum.Temperature, y = .resid)) + geom_point() + geom_smooth()
ggplot(filter_4440099.lm.df, aes(x = Relative.Humidity, y = .resid)) + geom_point() + geom_smooth()


filter_4440099.lm = lm(READ_VALUE ~  Maximum.Temperature + Relative.Humidity + Minimum.Temperature +
                       Conditions, 
                       data = filter_4440099)
summary(filter_4440099.lm)
filter_4440099.lm.df = augment(filter_4440099.lm)
ggplot(filter_4440099.lm.df, aes(x = Maximum.Temperature, y = .resid)) + geom_point() + geom_smooth()
ggplot(filter_4440099.lm.df, aes(x = Relative.Humidity, y = .resid)) + geom_point() + geom_smooth()


filter_4440099_1.lm = lm(Time ~  READ_VALUE, data = filter_4440099)
summary(filter_4440099_1.lm)
filter_4440099_1.lm.df = augment(filter_4440099.lm)
ggplot(filter_4440099_1.lm.df, aes(x = Maximum.Temperature, y = .resid)) + geom_point() + geom_smooth()
ggplot(filter_4440099_1.lm.df, aes(x = Relative.Humidity, y = .resid)) + geom_point() + geom_smooth()

# Fitting a regression model using all meters

merged_trim.lm = lm(READ_VALUE ~  Maximum.Temperature + Relative.Humidity, 
                       data = merged_trim)
summary(merged_trim.lm)

#merged_trim_null_removed = subset(merged_trim, !is.nan(merged_trim[[3]]))
merged_trim_null_removed <- filter(merged_trim, READ_VALUE >0)
View(merged_trim_null_removed)

# Transform to logscale
merged_trim_log.lm = lm(log(READ_VALUE) ~  Maximum.Temperature + Relative.Humidity, 
                    data = merged_trim_null_removed)
summary(merged_trim_log.lm)

merged_trim.lm.df = augment(merged_trim.lm)
ggplot(merged_trim.lm.df, aes(x = Maximum.Temperature, y = .resid)) + geom_point() + geom_smooth()
ggplot(merged_trim.lm.df, aes(x = Relative.Humidity, y = .resid)) + geom_point() + geom_smooth(method = 'gam')


gg = ggplot(merged_trim, aes(x = Maximum.Temperature, y = READ_VALUE)) + geom_point() + geom_smooth(method = "lm", se = FALSE)
gg + xlab("Maximum Ambient Temperature") + ylab("Peak Meter Reading") +
  ggtitle("Regression Line: Maximum Ambient Temperature vs Individual Peak Meter Reading")



gg = ggplot(merged_trim, aes(x = Relative.Humidity, y = READ_VALUE)) + geom_point() + geom_smooth(method = "lm", se = FALSE)
gg + xlab("Relative Humidity") + ylab("Peak Meter Reading") +
          ggtitle("Regression Line: Relative Humidity vs Individual Peak Meter Reading")

# Plotting using all meter data

ggplot(merged_trim, aes(x= Maximum.Temperature))+
  geom_density()

ggplot(merged_trim, aes(x= Minimum.Temperature))+
  geom_density()

ggplot(merged_trim, aes(x= Relative.Humidity))+
  geom_density()

ggplot(merged_trim, aes(x= READ_HR))+
  geom_density()

ggplot(merged_trim, aes(x= Wind.Chill))+
  geom_density()

ggplot(merged_trim, aes(x= Wind.Speed))+
  geom_density()

ggplot(merged_trim, aes(x= Cloud.Cover))+
  geom_density()

ggplot(merged_trim, aes(x= Conditions))+
  geom_density()

ggplot(merged_trim, aes(x= READ_VALUE))+
  geom_density()




# Dropping METER_ID column for day wise analysis

drops <- c("METER_ID")
group_max_trim_day = main_meters_trim[ , !(names(main_meters_trim) %in% drops)]

View(group_max_trim_day)

# Grouping datewise, hourwise and summing up
  
group_daily_df = group_max_trim_day %>% 
  group_by(Date, READ_HR) %>% 
  summarise_each(funs(sum))

View(group_daily_df)
View(weather_df_trim)

#Merging the dataframes
merged_daily_df <- weather_df_trim %>% right_join(group_daily_df, by=c("Date", "READ_HR"))
#merged_df = merged_df [!duplicated(merged_df[c(2,4)]),]
View(merged_daily_df)

# Filtering the maximum of the day
group_daily_max = merged_daily_df %>%
                      group_by(Date) %>%
                      slice(which.max(READ_VALUE))


# Dropping Date.time column
group_daily_max$Date.time <- NULL

# Reorder columns
group_daily_max <- group_daily_max[c(13,14,15, 1:12)]

View(group_daily_max)

# Plotting trends of daily max

ggplot(group_daily_max, aes(x= READ_HR))+
  geom_density()

ggplot(group_daily_max, aes(x= READ_VALUE))+
  geom_density()

ggplot(group_daily_max, aes(x= Maximum.Temperature))+
  geom_density() + ggtitle("Max Temperature vs Combined meter reading peak")

ggplot(group_daily_max, aes(x= Relative.Humidity))+
  geom_density() +  ggtitle("Relative Humidity vs Combined meter reading peak")


# Fitting a regression model using daily max
daily_max.lm = lm(READ_VALUE ~  Maximum.Temperature + Relative.Humidity,
                    data = group_daily_max)
summary(daily_max.lm)

# Selecting the best variables
daily_max.subsets = regsubsets(READ_VALUE ~ READ_HR + Maximum.Temperature + Relative.Humidity +
                                   Wind.Chill + Wind.Speed + Cloud.Cover + Conditions , data = group_daily_max)
summary(daily_max.subsets)

daily_max.lm_best = lm(READ_VALUE ~   Wind.Chill + Maximum.Temperature, 
                         data = group_daily_max)
summary(daily_max.lm_best)


gg = ggplot(daily_max, aes(x = Maximum.Temperature, y = READ_VALUE)) + geom_point() + geom_smooth(method = "lm", se = FALSE)
gg + xlab("Maximum Ambient Temperature") + ylab("Peak Total Meter Reading") +
   ggtitle("Regression Line: Maximum Ambient Temperature vs Peak Total Meter Reading")

# Include a Loess line
ggplot(group_daily_max, aes(x = Maximum.Temperature, y = READ_VALUE)) + geom_point() + geom_smooth(method = "lm",
                                                                         se = FALSE)+
geom_smooth(method = "loess", se = FALSE, color = "orange")

# Using logs
daily_max_log.lm = lm(log(READ_VALUE) ~  Maximum.Temperature + Relative.Humidity,
                  data = group_daily_max)

summary(daily_max_log.lm)

gg = ggplot(daily_max, aes(x = Relative.Humidity, y = READ_VALUE)) + geom_point() + geom_smooth(method = "lm", se = FALSE)
gg + xlab("Relative Humidity") + ylab("Peak Total Meter Reading") +
  ggtitle("Regression Line: Relative Humidity vs Peak Total Meter Reading")

# Checking relationship of various variables to READ_VALUE
gg = ggplot(group_daily_max, aes(x = Maximum.Temperature, y = log(READ_VALUE))) + geom_point()
gg + geom_smooth(method = "lm")
gg = ggplot(group_daily_max, aes(x = READ_HR, y = READ_VALUE)) + geom_point()+ geom_jitter()
gg + geom_smooth(method = "lm")
gg = ggplot(group_daily_max, aes(x = Relative.Humidity, y = log(READ_VALUE))) + geom_point()
gg + geom_smooth(method = "lm")
# Checking for normality of errors
ggplot(group_daily_max, aes(sample = Maximum.Temperature)) + stat_qq()
ggplot(group_daily_max, aes(sample = Relative.Humidity)) + stat_qq()

# Contor plot of Max temp and humidity
ggplot(group_daily_max, aes(x = Maximum.Temperature, y = Relative.Humidity)) + geom_point() + stat_density_2d()

# With color
ggplot(group_daily_max, aes(x = Maximum.Temperature, y = Relative.Humidity)) + stat_density_2d(aes(fill = ..level..),
                                                                geom = "polygon")


# Scatter plot of group_daily_max

library(GGally)

View(merged_trim)

library(leaps)
merged_trim.subsets = regsubsets(READ_VALUE ~ READ_HR + Maximum.Temperature + Relative.Humidity +
                  Wind.Chill + Wind.Speed + Cloud.Cover + Conditions , data = merged_trim)
summary(merged_trim.subsets)


merged_trim.lm_best = lm(READ_VALUE ~  READ_HR + Maximum.Temperature + Relative.Humidity,
                         data = merged_trim)
summary(merged_trim.lm_best)
