
setwd("D:\\Peak_Demand")

peak_daily = read.table("D:\\Peak_Demand\\iu_imputed_with_weather.txt",sep="\t", header = TRUE)

View(peak_daily)

library(mgcv)

# Create training and test sets
n.total = nrow(peak_daily)
n.train = n.total * 0.8
n.test = n.total - n.train
indices_train = sample(n.total, n.train)
indices_test = sample(n.total, n.test)
trainset = peak_daily[indices_train, ]
testset = peak_daily[indices_test, ]

nrow(trainset)
head(testset)

peak.gm.train.full = gam(READ_VALUE ~ s(READ_HR) + s(temperature) +
                      + s(relative_humidity) + s(MONTH) +  s(wind_speed) ,
                    method = "REML", select = TRUE,
                    data = trainset)

summary(peak.gm.train.full)

# Predict using this model
peak.read_val.full.predict = predict(peak.gm.train.full, newdata = testset)

predict.read_val.full.df = na.omit(data.frame(testset$READ_VALUE, peak.read_val.full.predict))

head(predict.read_val.full.df)
nrow(predict.read_val.full.df)

# Plot the prediction vs actual
plot(predict.read_val.full.df$ testset.READ_VALUE, predict.read_val.full.df$peak.read_val.full.predict)

pred_plot_1 = ggplot(predict.read_val.full.df, aes(x = testset.READ_VALUE, y = peak.read_val.full.predict))+
  geom_line(color = "orange") + xlab("READ_VALUE Test") + ylab("READ_VALUE predicted")

pred_plot_1

# Calculate RMSE
predict.read_val.full.df <- predict.read_val.full.df %>% mutate(error_square = (testset.READ_VALUE - 
                                                                        peak.read_val.full.predict) ^ 2)

predict.read_val.full.df = na.omit(predict.read_val.full.df)

head(predict.read_val.full.df)

mean(predict.read_val.df$error_square)

rmse_read_val_full = sqrt(mean(predict.read_val.full.df$error_square))   

rmse_read_val

# Model to predict peak demand timing

# Fitting a gam model to the training set to predict READ_HR

peak.gm.train.2 = gam(READ_HR ~ s(READ_VALUE) + s(temperature)+
                        + s(relative_humidity) + s(MONTH) +  s(wind_speed),
                        method = "REML", select = TRUE,
                      data = trainset)

summary(peak.gm.train.2)

# Predict using this model
peak.read_hr.predict.2 = predict(peak.gm.train.2, newdata = testset)

predict.read_hr.2.df = na.omit(data.frame(testset$READ_HR, peak.read_hr.predict.2))

head(predict.read_hr.2.df)

# Plot the prediction vs actual
plot(predict.read_hr.2.df$ testset.READ_HR, predict.read_hr.2.df$peak.read_hr.predict.2)

pred_plot_2 = ggplot(predict.read_hr.2.df, aes(x = testset.READ_HR, y = peak.read_hr.predict.2))+
  geom_line(color = "orange") + xlab("READ_HR Test") + ylab("READ_HR predicted")

pred_plot_2

# Calculate RMSE
predict.read_hr.2.df <- predict.read_hr.2.df %>% mutate(error_square = (testset.READ_HR - 
                                                                      peak.read_hr.predict.2) ^ 2)

predict.read_hr.2.df = na.omit(predict.read_hr.2.df)

head(predict.read_hr.2.df)

mean(predict.read_hr.2.df$error_square)

rmse_read_hr_2 = sqrt(mean(predict.read_hr.2.df$error_square))   

rmse_read_hr_2

# Cross checking the full dataset vs peak dataset models for predicting READ_VAL

check.df = read.csv("peak_daily_full.csv", header = TRUE)

# Predict using this model
peak.read_val.full.predict.2 = predict(peak.gm.train.full, newdata = check.df)

predict.read_val.full.df.2 = na.omit(data.frame(check.df$READ_VALUE, peak.read_val.full.predict.2))

head(predict.read_val.full.df.2)

# Calculate RMSE
predict.read_val.full.df.2 <- predict.read_val.full.df.2 %>% mutate(error_square = (check.df.READ_VALUE - 
                                                                                  peak.read_val.full.predict.2) ^ 2)

predict.read_val.full.df.2 = na.omit(predict.read_val.full.df.2)

head(predict.read_val.full.df.2)

rmse_read_val_full = sqrt(mean(predict.read_val.full.df.2$error_square))   

rmse_read_val_full

# Plot the prediction vs actual
plot(predict.read_val.full.df.2$check.df.READ_VALUE, predict.read_val.full.df.2$peak.read_val.full.predict.2)
