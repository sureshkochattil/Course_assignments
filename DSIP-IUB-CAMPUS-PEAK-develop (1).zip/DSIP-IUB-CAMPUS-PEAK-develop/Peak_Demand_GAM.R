
setwd("D:\\Peak_Demand")

peak_daily = read.csv("peak_daily_full.csv", header = TRUE)

head(peak_daily)

library(mgcv)

# Fitting a gam model
peak.gm = gam(READ_VALUE ~ s(READ_HR) + s(HOUR) + s(temperature)+
                + s(relative_humidity) + s(MONTH) +  s(wind_speed) +
                s(DAY), method = "REML", select = TRUE,
              data = peak_daily)

summary(peak.gm)

# Create training and test sets
n.total = nrow(peak_daily)
n.train = 300
n.test = 66
indices_train = sample(n.total, n.train)
indices_test = sample(n.total, n.test)
trainset = peak_daily[indices_train, ]
testset = peak_daily[indices_test, ]

head(testset)

# Fitting a gam model to the training set to predict READ_VALUE


peak.gm.train = gam(READ_VALUE ~ s(READ_HR) + s(HOUR) + s(temperature)+
                      + s(relative_humidity) + s(MONTH) +  s(wind_speed) +
                      s(DAY), method = "REML", select = TRUE,
                    data = trainset)

summary(peak.gm.train)

# Predict using this model
peak.read_val.predict = predict(peak.gm.train, newdata = testset)

predict.read_val.df = data.frame(testset$READ_VALUE, peak.read_val.predict )

head(predict.read_val.df)

# Plot the prediction vs actual
plot(predict.read_val.df$ testset.READ_VALUE, predict.read_val.df$peak.read_val.predict)

pred_plot_1 = ggplot(predict.read_val.df, aes(x = testset.READ_VALUE, y = peak.read_val.predict))+
  geom_line(color = "orange") + xlab("READ_VALUE Test") + ylab("READ_VALUE predicted")

pred_plot_1

# Calculate RMSE
predict.read_val.df <- predict.read_val.df %>% mutate(error_square = (testset.READ_VALUE - 
                                                                peak.read_val.predict) ^ 2)

predict.read_val.df = na.omit(predict.read_val.df)

head(predict.read_val.df)

mean(predict.read_val.df$error_square)

rmse_read_val = sqrt(mean(predict.read_val.df$error_square))   

rmse_read_val

# Model to predict peak demand timing

# Fitting a gam model to the training set to predict READ_VALUE

peak.gm.train.2 = gam(READ_HR ~ s(READ_VALUE) + s(HOUR) + s(temperature)+
                      + s(relative_humidity) + s(MONTH) +  s(wind_speed) +
                      s(DAY), method = "REML", select = TRUE,
                    data = trainset)

summary(peak.gm.train.2)

# Predict using this model
peak.read_hr.predict = predict(peak.gm.train.2, newdata = testset)

predict.read_hr.df = data.frame(testset$READ_HR, peak.read_hr.predict )

head(predict.read_hr.df)

# Plot the prediction vs actual
plot(predict.read_hr.df$ testset.READ_HR, predict.read_hr.df$peak.read_hr.predict)

pred_plot_2 = ggplot(predict.read_hr.df, aes(x = testset.READ_HR, y = peak.read_hr.predict))+
  geom_line(color = "orange") + xlab("READ_HR Test") + ylab("READ_HR predicted")

pred_plot_2

# Calculate RMSE
predict.read_hr.df <- predict.read_hr.df %>% mutate(error_square = (testset.READ_HR - 
                                                                        peak.read_hr.predict) ^ 2)

predict.read_hr.df = na.omit(predict.read_hr.df)

head(predict.read_hr.df)

mean(predict.read_hr.df$error_square)

rmse_read_hr = sqrt(mean(predict.read_hr.df$error_square))   

rmse_read_hr

