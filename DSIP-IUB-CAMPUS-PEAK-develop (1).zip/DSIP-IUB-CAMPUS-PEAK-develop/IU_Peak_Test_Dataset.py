# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 14:36:41 2020

@author: AdamSullivan
"""


# https://pyowm.readthedocs.io/en/latest/usage-examples-v2/weather-api-usage-examples.html

# Bloomington Lat: 39.1653° N, Long: 86.5264° W
# openweather id = 4254679

import numpy as np
import pandas as pd
import pyowm
from datetime import datetime, timedelta


owm = pyowm.OWM('02d982dc96589daaeebb1a7fd826930f')  # You MUST provide a valid API key

###############################################################################

# Get forecast

fc = owm.three_hours_forecast('Bloomington,IN,US')

f = fc.get_forecast()


###############################################################################

# Set right timezone
      
#hour_difference = f.get_reception_time('date').hour - datetime.now().hour
hour_difference = round((f.get_reception_time('date').replace(tzinfo=None) - datetime.now().replace(tzinfo=None)).seconds/3600)


###############################################################################

# Start Creating Dataset

cols = ['datetime','date','month','day','hour','weekday','temperature','precipitation','wind_speed','humidity','conditions']

df = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f: ## fix hour
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]  
    df.iloc[n,:] = data
    n += 1
      # does it always do GMT 12/3/6/9/12/3/6/9 or does it change based on hour pull?
      # 

#############33333 add date to be dropped later, and weekday and remember to add offsets to hour, day, month
      

###############################################################################

# Turn 3hr forecast to hourly

df_lower = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f:
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]   
    df_lower.iloc[n,:] = data
    n += 1
    
df_higher = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f:
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]   
    df_higher.iloc[n,:] = data
    n += 1



###############################################################################

# Combine dataframes
    
test_dataset = pd.concat([df,df_lower, df_higher])

test_dataset = test_dataset.reset_index()
test_dataset = test_dataset.drop('index', axis=1)

# change week day int to text
test_dataset['weekday'] = np.where((test_dataset.weekday == 0),'Monday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 1),'Tuesday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 2),'Wednesday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 3),'Thursday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 4),'Friday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 5),'Saturday',test_dataset.weekday)
test_dataset['weekday'] = np.where((test_dataset.weekday == 6),'Sunday',test_dataset.weekday)

###############################################################################
####### WIP ###################################################################
###############################################################################

# Add more variables

test_dataset['academic_period'] = 'Off'
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2020,8,24)) & (test_dataset['datetime'] <= datetime(2020,10,19)),'Fall 2020',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,1,11)) & (test_dataset['datetime'] <= datetime(2021,5,6)),'Spring 2021',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,5,17)) & (test_dataset['datetime'] <= datetime(2021,8,16)),'Summer 2021',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,8,23)) & (test_dataset['datetime'] <= datetime(2021,12,18)),'Fall 2021',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,1,10)) & (test_dataset['datetime'] <= datetime(2022,5,5)),'Spring 2022',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,5,16)) & (test_dataset['datetime'] <= datetime(2022,8,15)),'Summer 2022',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,8,22)) & (test_dataset['datetime'] <= datetime(2022,12,17)),'Fall 2022',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,1,9)) & (test_dataset['datetime'] <= datetime(2023,5,4)),'Spring 2023',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,5,15)) & (test_dataset['datetime'] <= datetime(2023,8,15)),'Summer 2023',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,8,21)) & (test_dataset['datetime'] <= datetime(2023,12,16)),'Fall 2023',test_dataset.academic_period)


test_dataset['SEASON'] = ''
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,3,19)) & (test_dataset.datetime < datetime(2020,6,20)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,6,20)) & (test_dataset.datetime < datetime(2020,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,9,22)) & (test_dataset.datetime < datetime(2020,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,12,21)) & (test_dataset.datetime < datetime(2021,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,3,20)) & (test_dataset.datetime < datetime(2021,6,20)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,6,20)) & (test_dataset.datetime < datetime(2021,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,9,22)) & (test_dataset.datetime < datetime(2021,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,12,21)) & (test_dataset.datetime < datetime(2022,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,3,20)) & (test_dataset.datetime < datetime(2022,6,21)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,6,21)) & (test_dataset.datetime < datetime(2022,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,9,22)) & (test_dataset.datetime < datetime(2022,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,12,21)) & (test_dataset.datetime <datetime( 2023,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2023,3,20)) & (test_dataset.datetime < datetime(2023,6,20)),'Spring',test_dataset.SEASON)


HOLIDAYS = [datetime(2020,9,7),datetime(2020,10,19),datetime(2020,10,20),datetime(2020,11,25),datetime(2020,11,26),datetime(2020,11,27),
            datetime(2021,1,18),datetime(2021,3,15),datetime(2021,3,16),datetime(2021,3,17),datetime(2021,3,18),datetime(2021,3,19),
            datetime(2021,5,31),datetime(2021,7,5),datetime(2021,9,6),datetime(2021,11,24),datetime(2021,11,25),datetime(2021,11,26),
            datetime(2022,1,17),datetime(2022,3,14),datetime(2022,3,15),datetime(2022,3,16),datetime(2022,3,17),datetime(2022,3,18),
            datetime(2022,5,30),datetime(2022,7,4),datetime(2022,9,5),datetime(2022,11,23),datetime(2022,11,24),datetime(2022,11,25)]



test_dataset['HOLIDAY'] = 0                                                                                 # OFF
test_dataset['HOLIDAY'] = np.where((test_dataset.date.isin(HOLIDAYS)) | (test_dataset.academic_period == 'Off') | (test_dataset.weekday.isin(['Saturday', 'Sunday'])), 1, test_dataset.HOLIDAY)


###############################################################################

# drop date column and reorder columns

test_dataset = test_dataset.drop('date', axis=1)

