
setwd("D:/Peak_Demand")

df = read.csv("peak_daily_full.csv", header = TRUE)
head(df)

demand.lm = lm(READ_HR ~ READ_VALUE + MONTH + HOUR + factor(WEEKDAY) + temperature +
                 wind_chill + wind_speed + relative_humidity + factor(conditions) +
                 factor(academic_period) + DAY + factor(SEASON) + factor(HOLIDAY),
                 data = df)

summary(demand.lm)

demand.lm.df = augment(demand.lm)
ggplot(demand.lm.df, aes(x = READ_HR, y = .resid)) + 
  geom_point() + geom_smooth()


demand.readval.lm = lm(READ_VALUE ~ READ_HR + MONTH + HOUR + factor(WEEKDAY) + temperature +
                 wind_chill + wind_speed + relative_humidity + factor(conditions) +
                 factor(academic_period) + DAY + factor(SEASON) + factor(HOLIDAY),
               data = df)

summary(demand.readval.lm)

demand.readval.lm.df = augment(demand.lm)
ggplot(demand.readval.lm.df, aes(x = READ_VALUE, y = .resid)) + 
  geom_point() + geom_smooth()