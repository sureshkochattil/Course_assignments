#!/usr/bin/env python
# coding: utf-8

"""
Created on Sat Apr 21 23:29:11 2020
@authors: Mallik Challa, Kunalan Ratharanjan and Adam Sullivan
"""

# # IUB Peak Demand - Forecasting Model

import numpy as np
import pandas as pd
import pyowm
import calendar
from datetime import datetime, timedelta
from pickle import load
from sklearn.base import BaseEstimator, TransformerMixin
from plotly.offline import init_notebook_mode, iplot
from IPython.display import display, HTML


# Weather Forecast data from OWM
owm = pyowm.OWM('02d982dc96589daaeebb1a7fd826930f')  # You MUST provide a valid API key

fc = owm.three_hours_forecast('Bloomington,IN,US')
f = fc.get_forecast()

hour_difference = round((f.get_reception_time('date').replace(tzinfo=None) - datetime.now().replace(tzinfo=None)).seconds/3600)


# Create Test Dataframe
cols = ['datetime','date', 'MONTH', 'DAY', 'HOUR', 'WEEKDAY','temperature','precipitation','wind_speed','relative_humidity','conditions']
df = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f: ## fix hour
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]  
    df.iloc[n,:] = data
    n += 1


df_lower = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f:
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference+1)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]   
    df_lower.iloc[n,:] = data
    n += 1


df_higher = pd.DataFrame(columns=cols, index=range(0,40))

n = 0
for weather in f:
    data = [weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1), (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).date(), 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).month, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).day, 
            (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).hour, (weather.get_reference_time('date').replace(tzinfo=None) - timedelta(hours=hour_difference-1)).weekday(), 
            weather.get_temperature('fahrenheit')['temp'], (0 if len(weather.get_rain()) == 0 else weather.get_rain()['3h']) + (0 if len(weather.get_snow()) == 0 else weather.get_snow()['3h']),
            weather.get_wind()['speed'], weather.get_humidity(), weather.get_status()]   
    df_higher.iloc[n,:] = data
    n += 1


test_dataset = pd.concat([df,df_lower, df_higher])
test_dataset = test_dataset.reset_index()
test_dataset = test_dataset.drop('index', axis=1)

# WEEKDAY feature addition
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 0),'Monday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 1),'Tuesday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 2),'Wednesday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 3),'Thursday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 4),'Friday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 5),'Saturday',test_dataset.WEEKDAY)
test_dataset['WEEKDAY'] = np.where((test_dataset.WEEKDAY == 6),'Sunday',test_dataset.WEEKDAY)

# academic_period feature addition
test_dataset['academic_period'] = 'Break'

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2020,1,13)) & (test_dataset['datetime'] <= datetime(2020,5,8)),'Spring_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2020,5,12)) & (test_dataset['datetime'] <= datetime(2020,8,12)),'Summer_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2020,8,24)) & (test_dataset['datetime'] <= datetime(2020,10,19)),'Fall_AP',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,1,11)) & (test_dataset['datetime'] <= datetime(2021,5,6)),'Spring_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,5,17)) & (test_dataset['datetime'] <= datetime(2021,8,16)),'Summer_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2021,8,23)) & (test_dataset['datetime'] <= datetime(2021,12,18)),'Fall_AP',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,1,10)) & (test_dataset['datetime'] <= datetime(2022,5,5)),'Spring_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,5,16)) & (test_dataset['datetime'] <= datetime(2022,8,15)),'Summer_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2022,8,22)) & (test_dataset['datetime'] <= datetime(2022,12,17)),'Fall_AP',test_dataset.academic_period)

test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,1,9)) & (test_dataset['datetime'] <= datetime(2023,5,4)),'Spring_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,5,15)) & (test_dataset['datetime'] <= datetime(2023,8,15)),'Summer_AP',test_dataset.academic_period)
test_dataset['academic_period'] = np.where((test_dataset['datetime'] >= datetime(2023,8,21)) & (test_dataset['datetime'] <= datetime(2023,12,16)),'Fall_AP',test_dataset.academic_period)


# SEASON feature addition
test_dataset['SEASON'] = ''
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,3,19)) & (test_dataset.datetime < datetime(2020,6,20)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,6,20)) & (test_dataset.datetime < datetime(2020,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,9,22)) & (test_dataset.datetime < datetime(2020,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2020,12,21)) & (test_dataset.datetime < datetime(2021,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,3,20)) & (test_dataset.datetime < datetime(2021,6,20)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,6,20)) & (test_dataset.datetime < datetime(2021,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,9,22)) & (test_dataset.datetime < datetime(2021,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2021,12,21)) & (test_dataset.datetime < datetime(2022,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,3,20)) & (test_dataset.datetime < datetime(2022,6,21)),'Spring',test_dataset.SEASON)

test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,6,21)) & (test_dataset.datetime < datetime(2022,9,22)),'Summer',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,9,22)) & (test_dataset.datetime < datetime(2022,12,21)),'Fall',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2022,12,21)) & (test_dataset.datetime <datetime( 2023,3,20)),'Winter',test_dataset.SEASON)
test_dataset['SEASON'] = np.where((test_dataset.datetime >= datetime(2023,3,20)) & (test_dataset.datetime < datetime(2023,6,20)),'Spring',test_dataset.SEASON)


# HOLIDAY feature addition
HOLIDAYS = [datetime(2020,9,7),datetime(2020,10,19),datetime(2020,10,20),datetime(2020,11,25),datetime(2020,11,26),datetime(2020,11,27),
            datetime(2021,1,18),datetime(2021,3,15),datetime(2021,3,16),datetime(2021,3,17),datetime(2021,3,18),datetime(2021,3,19),
            datetime(2021,5,31),datetime(2021,7,5),datetime(2021,9,6),datetime(2021,11,24),datetime(2021,11,25),datetime(2021,11,26),
            datetime(2022,1,17),datetime(2022,3,14),datetime(2022,3,15),datetime(2022,3,16),datetime(2022,3,17),datetime(2022,3,18),
            datetime(2022,5,30),datetime(2022,7,4),datetime(2022,9,5),datetime(2022,11,23),datetime(2022,11,24),datetime(2022,11,25)]

test_dataset['HOLIDAY'] = 0                                                                                 # OFF
test_dataset['HOLIDAY'] = np.where((test_dataset.date.isin(HOLIDAYS)) | (test_dataset.academic_period == 'Break') | (test_dataset.WEEKDAY.isin(['Saturday', 'Sunday'])), 1, test_dataset.HOLIDAY)


# Final test-dataset
test_dataset = test_dataset.drop('date', axis=1)
test_dataset = test_dataset.drop('datetime', axis=1)
forecast_df = test_dataset.sort_values(by=['DAY', 'HOUR']).reset_index().drop('index', axis=1)


ID = ['4440099', '4440104', '4440105', '4440177', '4440012', '4440073']


# Create a class to select numerical or categorical columns 
class DataFrameSelector(BaseEstimator, TransformerMixin):
    def __init__(self, attribute_names):
        self.attribute_names = attribute_names
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        return X[self.attribute_names].values


# Forecast Meter Readings
def main():
    
    for duke_id in ID:
        pipe_name = 'pipeline_' + duke_id + '.pkl'
        data_prep_pipeline = load(open(pipe_name, 'rb'))
        
        X_test_trans = data_prep_pipeline.transform(forecast_df)
#         print(X_test_trans.shape)
        
        model_name = 'model_' + duke_id + '.pkl'
        rf = load(open(model_name, 'rb'))
        
        forecast_df.loc[:, duke_id + '_KWH_PRED'] = rf.predict(X_test_trans) * 4
        
    forecast_df.loc[:, 'TOTAL_KWH_PRED'] = forecast_df.loc[:, '4440099_KWH_PRED' : '4440073_KWH_PRED'].sum(axis=1)
    
if __name__ == "__main__":
    main()


# Predicted Visualization Based on the sample data

init_notebook_mode(connected=True)

days = forecast_df['DAY'].unique()
month = calendar.month_name[int(forecast_df['MONTH'].unique())]
# create list of predicted columns
predicted_columns = ['4440099_KWH_PRED', '4440104_KWH_PRED', '4440105_KWH_PRED', 
                     '4440177_KWH_PRED', '4440012_KWH_PRED', '4440073_KWH_PRED', 'TOTAL_KWH_PRED']

# create figure
figure = {
    'data': [],
    'layout': {},
    'frames': []
}

# fill in most of layout
figure['layout']['xaxis'] = {'range': [0,23], 'title': 'Time(hour)', 'dtick': 1}
figure['layout']['yaxis'] = {'title': 'Predicted Meter Reading Value(kWh)'}
figure['layout']['title'] = {'text': 'Hourly Predicted Reading Value'}
figure['layout']['hovermode'] = 'closest'
figure['layout']['sliders'] = {
    'args': [
        'transition', {
            'duration': 400,
            'easing': 'cubic-in-out'
        }
    ],
    'initialValue': '1',
    'plotlycommand': 'animate',
    'values': days,
    'visible': True
}
figure['layout']['updatemenus'] = [
    {
        'buttons': [
            {
                'args': [None, {'frame': {'duration': 500, 'redraw': False},
                         'fromcurrent': True, 'transition': {'duration': 300, 'easing': 'quadratic-in-out'}}],
                'label': 'Play',
                'method': 'animate'
            },
            {
                'args': [[None], {'frame': {'duration': 0, 'redraw': False}, 'mode': 'immediate',
                'transition': {'duration': 0}}],
                'label': 'Pause',
                'method': 'animate'
            }
        ],
        'direction': 'left',
        'pad': {'r': 1, 't': 87},
        'showactive': False,
        'type': 'buttons',
        'x': 0.1,
        'xanchor': 'right',
        'y': 0,
        'yanchor': 'top'
    }
]

sliders_dict = {
    'active': 0,
    'yanchor': 'top',
    'xanchor': 'left',
    'currentvalue': {
        'font': {'size': 14},
        'prefix': 'Month: ' + month + '  ,  '+ 'Day: ',
        'visible': True,
        'xanchor': 'right'
    },
    'transition': {'duration': 300, 'easing': 'cubic-in-out'},
    'pad': {'b': 10, 't': 50},
    'len': 0.9,
    'x': 0.1,
    'y': 0,
    'steps': []
}

# make data
day = forecast_df['DAY'].unique()[0]
for predicted_column in predicted_columns:
    dataset_by_month = forecast_df[forecast_df['DAY'] == day]
    data_dict = {
        'x': list(dataset_by_month['HOUR']),
        'y': list(dataset_by_month['4440099_KWH_PRED']),
        'type': 'scatter',
        'text': predicted_columns,
        'name': predicted_column
    }
    figure['data'].append(data_dict)

# make frames
for day in days:
    frame = {'data': [], 'name': str(day)}
    for predicted_column in predicted_columns:
        dataset_by_month = forecast_df[forecast_df['DAY'] == day]

        data_dict = {
            'x': list(dataset_by_month['HOUR']),
            'y': list(dataset_by_month[predicted_column]),
            'type': 'scatter',
            'text': predicted_columns,
            'name': predicted_column
        }
        frame['data'].append(data_dict)

    figure['frames'].append(frame)
    slider_step = {'args': [
        [day],
        {'frame': {'duration': 300, 'redraw': False},
         'mode': 'immediate',
       'transition': {'duration': 300}}
     ],
     'label': str(day),
     'method': 'animate'}
    sliders_dict['steps'].append(slider_step)


figure['layout']['sliders'] = [sliders_dict]

iplot(figure)

