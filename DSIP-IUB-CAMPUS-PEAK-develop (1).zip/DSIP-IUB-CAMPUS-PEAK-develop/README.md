# IUB Campus Peak Coincident Demand Analysis

## Background:
The Energy Management Division of the Office of the VPCPF at Indiana University, Bloomington has embarked on an initiative to optimize the cost of energy supplies to their campus. As a part of this, they want to understand the impact of coincident demand on the cost, with the objective of identifying the sources of these demands as well as their timing.

## Objective:
The stated goals for this project as gleaned from the presentation deck and meeting with the Sponsor are as follows:
- Investigate ways to control/reduce demand at major contributors to peak coincident demand.
  - Potential for utility projects; building control system projects; R&R projects, etc.
- Establish values for minimum and maximum peak demand.
  - Defining these values will help quantify the impact of utility projects.
- Establish predictions for potential peak demand based on variable factors.
  - Predicting when we will hit peak coincident demand will allow us to take a proactive approach to minimizing it.

In pursuit of the above goals, the following short-term objectives have been called out:
- Integrating the current dataset with weather data.
- Visualization of data over a 24-hour period with a moving heat map to show how the consumption patterns change at the buildings and plants. 
- Defining and identifying worst case scenario and best-case scenario days.

