# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 10:08:22 2020

@author: AdamSullivan
"""


sqlfile = open('C:/Users/AdamSullivan/Documents/School/IUPeakProjectData.txt','r',encoding='utf8')

finalfile = open('C:/Users/AdamSullivan/Documents/School/IUPeakProjectDataMainMeters2.txt','w',encoding='utf8')

meter_list = ['4440099', '4440104', '4440105', '4440012', '4440073', '4440177','METER_I']

for aline in sqlfile:
    
    if aline[1:8] in meter_list:
        finalfile.write(aline)
 
        
        
finalfile.close()   
sqlfile.close()












