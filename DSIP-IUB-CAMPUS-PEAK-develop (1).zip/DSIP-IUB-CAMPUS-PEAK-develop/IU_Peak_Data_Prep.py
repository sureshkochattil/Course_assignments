# -*- coding: utf-8 -*-
"""
Created on Sat Mar 28 22:25:34 2020

@author: AdamSullivan
"""


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#relativePath=os.getcwd()
#readFilePath=relativePath+"\\IU_Peak.txt"

df = pd.read_csv('C:/Users/AdamSullivan/Documents/School/IUPeakProjectData.txt', sep="\t")
#df2 = df.copy()

df['READ_DT'] = pd.to_datetime(df['READ_DT'])
df['READ_DTM'] = pd.to_datetime(df['READ_DTM'])

#df.info()

# Fix Daylight Savings Time DateTimeStamps
read_dtm_field = df['READ_DTM'] == '2019-03-10 03:00:00'
read_hr_field = df['READ_HR'] == 2
df.loc[read_dtm_field & read_hr_field, 'READ_DTM'] = pd.to_datetime('2019-03-10 02:00:00')

read_dtm_field = df['READ_DTM'] == '2019-03-10 03:15:00'
read_hr_field = df['READ_HR'] == 3
df.loc[read_dtm_field & read_hr_field, 'READ_DTM'] = pd.to_datetime('2019-03-10 02:15:00')

read_dtm_field = df['READ_DTM'] == '2019-03-10 03:30:00'
read_hr_field = df['READ_HR'] == 3
df.loc[read_dtm_field & read_hr_field, 'READ_DTM'] = pd.to_datetime('2019-03-10 02:30:00')

read_dtm_field = df['READ_DTM'] == '2019-03-10 03:45:00'
read_hr_field = df['READ_HR'] == 3
df.loc[read_dtm_field & read_hr_field, 'READ_DTM'] = pd.to_datetime('2019-03-10 02:45:00')

del read_dtm_field
del read_hr_field

df = df.drop(['CHANNEL_ID', 'READ_5MIN_INT', 'UOM', 'STATUS', 'READ_VERSION'],axis=1)

#df.set_index('READ_DTM',drop=False,inplace=True)

#df.head()
###############################################################################
duke_ids = ['4440099', '4440105', '4440012', '4440073', '4440177'] # '4440104',

df_new = df[df.iloc[:, 0].isin(duke_ids)]
#df = df_duke.copy()

#df2['READ_DT'] = pd.to_datetime(df2['READ_DT'])
#df2['READ_DTM'] = pd.to_datetime(df2['READ_DTM'])

df_4440104 = df[df.iloc[:, 0].isin(['4440104'])]

#df_4440104_2 = df_4440104.copy()

df_4440104.loc['READ_DT'] = pd.to_datetime(df_4440104['READ_DT'])
end_date = df_4440104['READ_DT'] < '03-28-2019'

df_4440104 = df_4440104[end_date]


df_new2 = pd.concat([df_new,df_4440104])


###############################################################################

#column_names = ['METER_ID', 'CHANNEL_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_5MIN_INT', 'READ_DTM', 'READ_VALUE', 'UOM', 'STATUS', 'READ_VERSION']
column_names = ['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM', 'READ_VALUE']

meter_4440104_meters_ids = ['4440017','4440038','4440081','4440084','4440107','4440109','4440110','4440111','4440112','4440113','4440116','4440117',
                            '4440135','4440136','KZD052439471','KZD052439548','KZD052439555','KZD052439556','X8D054382940','X9D053773966','X9D053773967','X9D053806594','X9D053806620',
                            '4440018','4440030','4440015','4440036','4440005','4440011']

df_4440104_meters_ids = df[df.iloc[:, 0].isin(meter_4440104_meters_ids)]  #704232 records

df_4440104_meters_ids.loc[:,'METER_ID'] = '4440104' #704232 records
#df_4440104_meters_ids.loc[:,'STATUS'] = '1' 

#df = df_4440104_meters_ids.copy()

#df_4440104_grouped = df.groupby(['METER_ID', 'CHANNEL_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_5MIN_INT', 'READ_DTM', 'UOM', 'STATUS', 'READ_VERSION']).sum().reset_index()
df_4440104_grouped = df_4440104_meters_ids.groupby(['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM']).sum().reset_index()

df_4440104_grouped = df_4440104_grouped.reindex(columns=column_names)

#df = df_4440104_grouped.copy()

meter_estimates = [['03-28-2019', '04-29-2019', 2687530], 
                   ['04-29-2019', '05-29-2019', 2242982], 
                   ['05-29-2019', '06-27-2019', 2088403], 
                   ['06-27-2019', '07-29-2019', 2931763], 
                   ['07-29-2019', '08-27-2019', 2709715], 
                   ['08-27-2019', '09-26-2019', 2861270], 
                   ['09-26-2019', '10-25-2019', 2439763], 
                   ['10-25-2019', '11-26-2019', 3014534], 
                   ['11-26-2019', '12-28-2019', 3134141] ]

#month = ['03-28-2019', '04-29-2019', 2687530]

for month in meter_estimates:
    start,end,total = month

    start_date = df_4440104_grouped['READ_DT'] >= start
    end_date = df_4440104_grouped['READ_DT'] < end
    
    df_slice = df_4440104_grouped[start_date & end_date]
    
    ratio = total / df_slice['READ_VALUE'].sum()

    df_slice.loc[:,'READ_VALUE'] = round(df_slice['READ_VALUE'] * ratio,2)
        
    df_new2 = pd.concat([df_new2,df_slice])



start = '12-28-2019'
start_date = df_4440104_grouped['READ_DT'] >= start
df_slice = df_4440104_grouped[start_date]
df_slice.loc[:, 'READ_VALUE'] = round(df_slice['READ_VALUE'] * ratio)
df_new2 = pd.concat([df_new2,df_slice])


#df_new2.to_csv('C:/Users/AdamSullivan/Documents/School/IUPeakProjectDataMainMeters3.txt', sep="\t", index=False)
df_data = df_new2.copy()

###############################################################################
###############################################################################

#df = pd.read_csv('C:/Users/AdamSullivan/Documents/School/IUPeakProjectDataMainMeters3.txt', sep="\t")

df_data['READ_DT'] = pd.to_datetime(df_data['READ_DT'])
df_data['READ_DTM'] = pd.to_datetime(df_data['READ_DTM'])

#df_data.info()

df_data['METER_4440104_MAIN'] = 0.0
df_data['METER_4440012_MAIN_CHILLER'] = 0.0
df_data['METER_4440073_MAIN_CHILLER'] = 0.0
df_data['METER_4440177_MAIN'] = 0.0
df_data['METER_4440105_MAIN'] = 0.0
df_data['METER_4440099_MAIN'] = 0.0


main_meter_list = [['4440104', 'METER_4440104_MAIN'],
                   ['4440012', 'METER_4440012_MAIN_CHILLER'],
                   ['4440073', 'METER_4440073_MAIN_CHILLER'],
                   ['4440177', 'METER_4440177_MAIN'],
                   ['4440105', 'METER_4440105_MAIN'],
                   ['4440099', 'METER_4440099_MAIN'] ]

for m in main_meter_list:
    meter_num, label = m
    meter = df_data['METER_ID'] == meter_num
    df_data.loc[meter, label] = df_data.loc[meter, 'READ_VALUE'] 
    

#df_data[df_data.index.duplicated()]

#df_data['METER_ID'].value_counts()

#df = df.drop(['METER_ID','CHANNEL_ID', 'READ_5MIN_INT', 'UOM', 'STATUS', 'READ_VERSION'],axis=1)
df_data = df_data.drop(['METER_ID'],axis=1)


df_grouped = df_data.groupby(['READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM']).sum().reset_index()

df_grouped.set_index('READ_DTM',drop=False,inplace=True)
#df_grouped[df_grouped.index.duplicated()]
###############################################################################
###############################################################################

# chiller meters - 4440145, 4440071, 4440134, 4440106 # , 4440073, 4440012

df_4440145 = df[df.iloc[:, 0].isin(['4440145'])]
df_4440071 = df[df.iloc[:, 0].isin(['4440071'])]
df_4440134 = df[df.iloc[:, 0].isin(['4440134'])]
df_4440106 = df[df.iloc[:, 0].isin(['4440106'])]

df_4440145.set_index('READ_DTM',drop=False,inplace=True)
df_4440071.set_index('READ_DTM',drop=False,inplace=True)
df_4440134.set_index('READ_DTM',drop=False,inplace=True)
df_4440106.set_index('READ_DTM',drop=False,inplace=True)

df_4440145 = df_4440145.drop(['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM'],axis=1)
df_4440071 = df_4440071.drop(['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM'],axis=1)
df_4440134 = df_4440134.drop(['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM'],axis=1)
df_4440106 = df_4440106.drop(['METER_ID', 'READ_DT', 'READ_HR', 'READ_30MIN_INT', 'READ_15MIN_INT', 'READ_DTM'],axis=1)

df_4440145 = df_4440145.rename(columns={'READ_VALUE': 'METER_4440145_CHILLER'})
df_4440071 = df_4440071.rename(columns={'READ_VALUE': 'METER_4440071_CHILLER'})
df_4440134 = df_4440134.rename(columns={'READ_VALUE': 'METER_4440134_CHILLER'})
df_4440106 = df_4440106.rename(columns={'READ_VALUE': 'METER_4440106_CHILLER'})

#df_4440145.info()
#results = df_4440145.index.duplicated()
#results.nonzero()


###############################################################################
df_merge = pd.merge(df_grouped, df_4440145, left_index = True, right_index = True, how='outer') #, left_on=['DATE','HOUR'], right_on = ['DATE','HOUR'])
df_merge = pd.merge(df_merge, df_4440071, left_index = True, right_index = True, how='outer') #, left_on=['DATE','HOUR'], right_on = ['DATE','HOUR'])
df_merge = pd.merge(df_merge, df_4440134, left_index = True, right_index = True, how='outer') #, left_on=['DATE','HOUR'], right_on = ['DATE','HOUR'])
df_merge = pd.merge(df_merge, df_4440106, left_index = True, right_index = True, how='outer') #, left_on=['DATE','HOUR'], right_on = ['DATE','HOUR'])

df_merge['MONTH'] = df_merge['READ_DTM'].dt.month
df_merge['HOUR'] = df_merge['READ_DTM'].dt.hour
df_merge['DATE'] = df_merge['READ_DTM'].dt.date
df_merge['WEEKDAY'] = df_merge['READ_DTM'].dt.weekday_name

df_data = df_merge.copy()

###############################################################################

df_weather = pd.read_csv('C:/Users/AdamSullivan/Documents/School/weather_2019_hourly.csv', sep=",")
df_weather.columns = df_weather.columns.str.replace(" ","_").str.lower()


df_weather.date_time = pd.to_datetime(df_weather.date_time)
df_weather['HOUR'] = df_weather['date_time'].dt.hour
df_weather['DATE'] = df_weather['date_time'].dt.date

df_weather = df_weather.drop(['maximum_temperature', 'minimum_temperature', 'snow_depth', 'location', 'address', 'resolved_address', 'heat_index', 'wind_gust',  'cloud_cover', 'contributing_stations'], axis=1)


#df_weather.info()
#df_weather.isnull().sum()




df_data = pd.merge(df_data, df_weather,  how='left', left_on=['DATE','HOUR'], right_on = ['DATE','HOUR'])
#df_data.info()



df_data['academic_period'] = 'off'
df_data['academic_period'] = np.where((df_data['READ_DTM'] >= '2019-01-07') & (df_data['READ_DTM'] <= '2019-05-03'),'Spring 2019',df_data.academic_period)
df_data['academic_period'] = np.where((df_data['READ_DTM'] >= '2019-05-07') & (df_data['READ_DTM'] <= '2019-07-26'),'Summer 2019',df_data.academic_period)
df_data['academic_period'] = np.where((df_data['READ_DTM'] >= '2019-08-26') & (df_data['READ_DTM'] <= '2019-12-20'),'Fall 2019',df_data.academic_period)


#df_data.head()
